"""
API 키·네트워크 없이 요구사항을 검증하는 모의 테스트.
OpenAI 서버 응답(post_api)만 가짜로 바꾸고, 나머지 코드는 실제로 실행한다.

실행: python test_mock.py
"""
import base64
import builtins
import io
import json
import os
import shutil
import sys
from pathlib import Path
from unittest import mock

from PIL import Image

sys.path.insert(0, str(Path(__file__).parent))
import brand_generator as bg

os.chdir(Path(__file__).parent)
bg.time.sleep = lambda s: None  # 재시도 대기 생략


def chat(obj):
    return {"choices": [{"message": {"content": json.dumps(obj, ensure_ascii=False)}}]}


def img_b64(fmt="PNG"):
    buf = io.BytesIO()
    Image.new("RGB", (64, 64), "#2E7D32").save(buf, format=fmt)
    return {"data": [{"b64_json": base64.b64encode(buf.getvalue()).decode()}]}


STORY_OK = "가" * 295
RESPONSES = {
    "브랜드명 후보": {"names": [
        {"korean": "블루밍", "english": "Blooming", "meaning": "자연에서 피어나는 아름다움"},
        {"korean": "소소담", "english": "Sosodam", "meaning": "소소한 일상에 자연을 담다"},
        {"korean": "어반리프", "english": "Urban Leaf", "meaning": "도시 속 자연의 싱그러움"},
        {"korean": "온결", "english": "Ongyeol", "meaning": "따뜻한 결을 지닌 피부"}]},
    "슬로건": {"slogans": ["일상에 자연을 담다", "피부가 숨쉬는 순간", "자연 그대로, 당신 그대로"]},
    "브랜드 스토리": {"origin": "배경", "philosophy": "철학", "vision": "비전", "story": STORY_OK},
    "컬러 팔레트": {"main": {"hex": "#2e7d32", "name": "Forest Green", "reason": "자연"},
                "sub": [{"hex": "81C784", "name": "Leaf"}, {"hex": "#E8F5E9", "name": "Mist"},
                        {"hex": "#F4E1C1", "name": "Sand"}]},
    "경쟁사를 분석": {"competitors": [{"name": "이니스프리"}], "differentiation": ["비건 인증", "리필 패키지"]},
}


def make_fake(overrides=None):
    overrides = overrides or {}
    calls = {"n": 0}

    def fake_post(endpoint, payload, key, timeout=120):
        calls["n"] += 1
        if endpoint == "images/generations":
            if "images" in overrides:
                return overrides["images"](payload)
            return img_b64()
        prompt = payload["messages"][1]["content"]
        for marker, resp in RESPONSES.items():
            if marker in prompt:
                if marker in overrides:
                    return overrides[marker](prompt)
                return chat(resp)
        raise AssertionError("알 수 없는 프롬프트: " + prompt[:40])

    return fake_post, calls


def run_main(inputs, env_key="sk-test-0000000000000000000"):
    feed = iter(inputs)
    env = {"OPENAI_API_KEY": env_key} if env_key else {}
    with mock.patch.dict(os.environ, env, clear=False), \
            mock.patch.object(builtins, "input", lambda prompt="": (print(prompt, end=""), next(feed))[1]):
        if not env_key:
            os.environ.pop("OPENAI_API_KEY", None)
        try:
            bg.main()
            return 0
        except SystemExit as e:
            return e.code


def section(title):
    print("\n" + "=" * 60 + f"\n▶ {title}\n" + "=" * 60)


shutil.rmtree("output", ignore_errors=True)

# ── A. 정상 흐름: 잘못된 경로 재입력 → 기본 출력 폴더(./output) ──
section("A. 정상 흐름 (잘못된 경로 1회 → brief.json, 출력 폴더 엔터)")
fake, _ = make_fake({"images": lambda p: img_b64("JPEG")})  # JPEG로 받아도 PNG로 저장되는지
with mock.patch.object(bg, "post_api", fake):
    assert run_main(["nope.json", "brief.json", ""]) == 0
out = Path("output")
data = json.loads((out / "brand_result.json").read_text(encoding="utf-8"))
assert 3 <= len(data["names"]) <= 5 and all(n["meaning"] and n["english"] for n in data["names"])
assert len(data["slogans"]) == 3
assert 250 <= data["story"]["length"] <= 350 and data["story"]["origin"] and data["story"]["vision"]
assert data["color_palette"]["main"]["hex"] == "#2E7D32"
assert 2 <= len(data["color_palette"]["sub"]) <= 3 and data["color_palette"]["sub"][0]["hex"] == "#81C784"
assert (out / "color_palette.png").read_bytes()[:8] == b"\x89PNG\r\n\x1a\n"
for i in (1, 2):
    assert (out / f"logo_{i:02d}.png").read_bytes()[:8] == b"\x89PNG\r\n\x1a\n"
assert data["competitor_analysis"]["differentiation"] and data["errors"] == []

# ── B. 단계 실패 시 다음 단계 계속 + 스토리 길이 재생성 ──
section("B. 슬로건 서버 오류(재시도 후 실패) + 스토리 길이 초과 → 재생성")
story_calls = {"n": 0}


def long_then_ok(prompt):
    story_calls["n"] += 1
    s = "나" * 600 if story_calls["n"] == 1 else STORY_OK
    return chat({"origin": "a", "philosophy": "b", "vision": "c", "story": s})


fake, _ = make_fake({"브랜드 스토리": long_then_ok})
real_post = bg.post_api


def post_with_500(endpoint, payload, key, timeout=120):
    if endpoint == "chat/completions" and "슬로건" in payload["messages"][1]["content"]:
        resp = mock.Mock(status_code=500, text="err", json=lambda: {"error": {"message": "server error"}})
        with mock.patch.object(bg.requests, "post", return_value=resp):
            return real_post(endpoint, payload, key, timeout)
    return fake(endpoint, payload, key, timeout)


with mock.patch.object(bg, "post_api", post_with_500):
    assert run_main(["brief.json", "output_b"]) == 0
data = json.loads(Path("output_b/brand_result.json").read_text(encoding="utf-8"))
assert [e["stage"] for e in data["errors"]] == ["slogan"]
assert story_calls["n"] == 2 and data["story"]["length"] == 295
assert Path("output_b/logo_02.png").exists()

# ── C. 잘못된 API 키(401) → 안내 출력, 나머지 단계 건너뛰고 JSON 저장 ──
section("C. 잘못된 API 키 (HTTP 401)")
resp401 = mock.Mock(status_code=401, text="", json=lambda: {"error": {"message": "Incorrect API key"}})
with mock.patch.object(bg.requests, "post", return_value=resp401) as m:
    assert run_main(["brief.json", "output_c"]) == 0
    assert m.call_count == 1  # 401 이후 불필요한 호출 없음
data = json.loads(Path("output_c/brand_result.json").read_text(encoding="utf-8"))
assert len(data["errors"]) == 6

# ── D. API 키 없음 / 형식 오류 ──
section("D. API 키 없음")
with mock.patch.object(bg, "Path", lambda p: Path("/nonexistent") / p):  # .env/config.json 무시
    assert run_main([], env_key=None) == 1
section("D-2. API 키 형식 오류")
assert run_main([], env_key="abc123") == 1

# ── E. 브리프 필수 필드 누락 ──
section("E. 필수 필드 누락 브리프")
Path("bad_brief.json").write_text('{"industry": "카페"}', encoding="utf-8")
try:
    bg.load_brief("bad_brief.json")
    raise AssertionError("검증 실패")
except ValueError as e:
    print("  ", str(e).splitlines()[0])
finally:
    os.remove("bad_brief.json")

for d in ("output_b", "output_c"):
    shutil.rmtree(d, ignore_errors=True)
print("\n✅ 모든 모의 테스트 통과")
