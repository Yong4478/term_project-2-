"""
🎨 AI 브랜드 아이덴티티 생성기 (CLI)

브랜드 브리프(JSON)를 입력받아 LLM API와 이미지 생성 API로
  [1/5] 브랜드 네이밍 후보 3~5개 + 의미 (한글/영문 동시 생성 - 보너스)
  [2/5] 슬로건/태그라인 3개 (톤앤매너 반영)
  [3/5] 브랜드 스토리 300자 내외 (탄생 배경·철학·비전)
  [4/5] 컬러 팔레트 (메인 1 + 서브 2~3, HEX) → color_palette.png
  [5/5] 로고 시안 2개 → logo_01.png, logo_02.png
  [보너스] 경쟁사 분석 및 차별화 포인트 (competitors 입력 시)
를 생성하고, 모든 텍스트 결과를 brand_result.json으로 저장한다.

▶ API 키는 코드에 작성하지 않는다. 다음 순서로 읽는다.
  1. 환경 변수 OPENAI_API_KEY
  2. 실행 폴더의 .env 파일      (OPENAI_API_KEY=sk-...)
  3. 실행 폴더의 config.json 파일 ({"OPENAI_API_KEY": "sk-..."})

▶ 선택 환경 변수
  OPENAI_MODEL        텍스트 생성 모델 (기본: gpt-4o-mini)
  OPENAI_IMAGE_MODEL  이미지 생성 모델 (기본: dall-e-3, 실패 시 gpt-image-1로 재시도)

실행: python brand_generator.py   (Python 3.10 이상)
"""

from __future__ import annotations

import base64
import io
import json
import os
import re
import sys
import time
from pathlib import Path

import requests

import matplotlib

matplotlib.use("Agg")  # 화면 없이 PNG 파일로만 저장
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import Rectangle
from PIL import Image  # matplotlib 설치 시 함께 설치됨 (PNG 변환·검증용)

# ─────────────────────────────────────────────
# 설정
# ─────────────────────────────────────────────
API_BASE = "https://api.openai.com/v1"
TEXT_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
IMAGE_MODEL = os.getenv("OPENAI_IMAGE_MODEL", "dall-e-3")
FALLBACK_IMAGE_MODEL = "gpt-image-1"

DEFAULT_OUTPUT_DIR = "./output"
RESULT_FILENAME = "brand_result.json"
PALETTE_FILENAME = "color_palette.png"
LOGO_COUNT = 2                 # 요구사항: 2~3개
NAME_MIN, NAME_MAX = 3, 5      # 요구사항: 3~5개
SLOGAN_COUNT = 3               # 요구사항: 3개
SUB_MIN, SUB_MAX = 2, 3        # 요구사항: 서브 컬러 2~3개
STORY_TARGET, STORY_TOLERANCE = 300, 50   # 요구사항: 300자 내외 (250~350자 허용)

MAX_RETRIES = 3                # 일시적 오류(429/5xx/네트워크) 재시도 횟수
REQUIRED_FIELDS = ("industry", "target", "keywords")
OPTIONAL_FIELDS = ("tone", "competitors", "notes")
HEX_RE = re.compile(r"^#[0-9A-Fa-f]{6}$")
TOTAL_STEPS = 5


# ─────────────────────────────────────────────
# 예외 정의
# ─────────────────────────────────────────────
class APIKeyError(Exception):
    """API 키가 없거나 잘못된 경우."""


class APICallError(Exception):
    """개별 API 호출 실패 (해당 단계만 실패 처리하고 다음 단계로 진행)."""


class NonRetryableError(APICallError):
    """재시도해도 해결되지 않는 오류 (400/403/404, 크레딧 소진 등)."""


# ─────────────────────────────────────────────
# API 키 관리
# ─────────────────────────────────────────────
SCRIPT_DIR = Path(__file__).resolve().parent

KEY_GUIDE = (
    "   다음 중 한 가지 방법으로 OpenAI API 키를 설정한 뒤 다시 실행하세요.\n"
    '   - Windows PowerShell : $env:OPENAI_API_KEY="sk-..."\n'
    "   - Windows cmd        : set OPENAI_API_KEY=sk-...\n"
    "   - macOS/Linux        : export OPENAI_API_KEY=sk-...\n"
    f"   - .env 파일          : {SCRIPT_DIR / '.env'} 에 OPENAI_API_KEY=sk-... 한 줄 저장\n"
    "   키 발급: https://platform.openai.com/api-keys"
)


def _config_candidates(filename: str) -> list[Path]:
    """현재 폴더와 프로그램 파일이 있는 폴더 양쪽에서 설정 파일을 찾는다."""
    paths = [Path(filename), SCRIPT_DIR / filename]
    return [p for i, p in enumerate(paths) if p.resolve() not in {q.resolve() for q in paths[:i]}]


def load_api_key() -> str:
    """환경 변수 → .env → config.json 순서로 API 키를 읽는다."""
    key = os.getenv("OPENAI_API_KEY", "").strip()

    for env_file in _config_candidates(".env"):
        if key or not env_file.is_file():
            continue
        # utf-8-sig: Windows 메모장이 붙이는 BOM 제거
        for line in env_file.read_text(encoding="utf-8-sig").splitlines():
            line = line.strip()
            if line.startswith("OPENAI_API_KEY"):
                _, _, value = line.partition("=")
                key = value.strip().strip('"').strip("'")
                break

    for config_file in _config_candidates("config.json"):
        if key or not config_file.is_file():
            continue
        try:
            key = str(json.loads(config_file.read_text(encoding="utf-8-sig")).get("OPENAI_API_KEY", "")).strip()
        except (json.JSONDecodeError, AttributeError):
            print(f"⚠️  {config_file} 파일을 읽을 수 없습니다. JSON 형식을 확인하세요.")

    if not key:
        raise APIKeyError("API 키가 설정되어 있지 않습니다.\n" + KEY_GUIDE)
    if not key.startswith("sk-") or len(key) < 20:
        raise APIKeyError("API 키 형식이 올바르지 않습니다. (OpenAI 키는 'sk-'로 시작합니다)\n" + KEY_GUIDE)
    return key


# ─────────────────────────────────────────────
# API 호출 공통 처리 (재시도 + 오류 분류)
# ─────────────────────────────────────────────
def post_api(endpoint: str, payload: dict, api_key: str, timeout: int = 120) -> dict:
    """OpenAI REST API에 POST 요청을 보내고 JSON 응답을 반환한다."""
    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
    url = f"{API_BASE}/{endpoint}"
    last_error = ""

    for attempt in range(1, MAX_RETRIES + 1):
        try:
            resp = requests.post(url, headers=headers, json=payload, timeout=timeout)
        except requests.Timeout:
            last_error = "요청 시간이 초과되었습니다."
        except requests.ConnectionError:
            last_error = "네트워크에 연결할 수 없습니다. 인터넷 연결을 확인하세요."
        else:
            if resp.status_code == 200:
                try:
                    return resp.json()
                except ValueError as e:
                    raise NonRetryableError("API 응답을 해석할 수 없습니다.") from e

            try:
                msg = resp.json().get("error", {}).get("message", "") or resp.text[:200]
            except ValueError:
                msg = resp.text[:200]

            if resp.status_code == 401:
                raise APIKeyError("API 키가 잘못되었거나 만료되었습니다. (HTTP 401)\n" + KEY_GUIDE)
            if resp.status_code == 429 and ("quota" in msg.lower() or "billing" in msg.lower()):
                raise NonRetryableError("API 사용 한도(크레딧)를 초과했습니다. 결제/한도 설정을 확인하세요.")
            if resp.status_code in (400, 403, 404):
                raise NonRetryableError(f"HTTP {resp.status_code}: {msg}")
            # 429(속도 제한), 5xx(서버 오류)는 잠시 후 재시도
            last_error = f"HTTP {resp.status_code}: {msg}"

        if attempt < MAX_RETRIES:
            wait = 2 ** attempt
            print(f"      ⚠ {last_error} → {wait}초 후 재시도 ({attempt}/{MAX_RETRIES - 1})")
            time.sleep(wait)

    raise APICallError(f"{MAX_RETRIES}회 시도했지만 실패했습니다: {last_error}")


def ask_llm_json(user_prompt: str, api_key: str) -> dict:
    """LLM API를 호출하여 JSON 객체 응답을 dict로 반환한다."""
    payload = {
        "model": TEXT_MODEL,
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_prompt},
        ],
        "response_format": {"type": "json_object"},
        "temperature": 0.9,
    }
    data = post_api("chat/completions", payload, api_key)
    try:
        content = data["choices"][0]["message"]["content"]
        result = json.loads(content)
    except (KeyError, IndexError, TypeError, json.JSONDecodeError) as e:
        raise APICallError(f"LLM 응답 형식이 올바르지 않습니다: {e}") from e
    if not isinstance(result, dict):
        raise APICallError("LLM 응답이 JSON 객체가 아닙니다.")
    return result


def generate_image(prompt: str, api_key: str) -> bytes:
    """이미지 생성 API(DALL-E 등)를 호출하여 PNG 바이트를 반환한다."""
    models = [IMAGE_MODEL] + ([FALLBACK_IMAGE_MODEL] if IMAGE_MODEL != FALLBACK_IMAGE_MODEL else [])
    last_exc: Exception | None = None

    for model in models:
        payload = {"model": model, "prompt": prompt, "n": 1, "size": "1024x1024"}
        if model.startswith("dall-e"):
            payload["response_format"] = "b64_json"  # gpt-image 계열은 항상 b64로 응답
        try:
            data = post_api("images/generations", payload, api_key, timeout=180)
        except NonRetryableError as e:
            # 모델 미지원·권한 없음 등은 대체 모델로 한 번 더 시도
            last_exc = e
            if model != models[-1]:
                print(f"      ⚠ {model} 사용 불가 → {models[-1]} 모델로 재시도")
            continue

        try:
            item = data["data"][0]
        except (KeyError, IndexError, TypeError) as e:
            raise APICallError("이미지 응답에 데이터가 없습니다.") from e
        if item.get("b64_json"):
            raw = base64.b64decode(item["b64_json"])
        elif item.get("url"):
            r = requests.get(item["url"], timeout=60)
            r.raise_for_status()
            raw = r.content
        else:
            raise APICallError("이미지 응답에 데이터가 없습니다.")
        return to_png_bytes(raw)

    raise last_exc or APICallError("이미지 생성에 실패했습니다.")


def to_png_bytes(raw: bytes) -> bytes:
    """어떤 형식으로 받든 PNG로 변환해 반환한다 (요구사항: PNG 파일로 저장)."""
    try:
        with Image.open(io.BytesIO(raw)) as img:
            if img.format == "PNG":
                return raw
            buf = io.BytesIO()
            img.save(buf, format="PNG")
            return buf.getvalue()
    except Exception as e:
        raise APICallError(f"받은 이미지를 PNG로 변환할 수 없습니다: {e}") from e


# ─────────────────────────────────────────────
# 브랜드 브리프 입력
# ─────────────────────────────────────────────
def load_brief(path: str) -> dict:
    """JSON 브리프 파일을 읽고 필수 필드를 검증한다."""
    p = Path(path).expanduser()
    if not p.is_file():
        raise ValueError(f"브리프 파일을 찾을 수 없습니다: {path}")
    try:
        brief = json.loads(p.read_text(encoding="utf-8-sig"))
    except json.JSONDecodeError as e:
        raise ValueError(f"브리프 파일이 올바른 JSON 형식이 아닙니다: {e}") from e
    except UnicodeDecodeError:
        raise ValueError("브리프 파일을 UTF-8로 읽을 수 없습니다. 인코딩을 확인하세요.")
    if not isinstance(brief, dict):
        raise ValueError("브리프 파일은 { } 로 감싼 JSON 객체여야 합니다.")

    missing = [f for f in REQUIRED_FIELDS if not brief.get(f)]
    if missing:
        raise ValueError(
            f"필수 필드가 없습니다: {', '.join(missing)}\n"
            "   필수: industry(업종), target(타겟), keywords(키워드)\n"
            "   선택: tone(톤앤매너), competitors(경쟁사), notes(추가 요청사항)"
        )

    # 키워드/경쟁사는 문자열("a, b")로 들어와도 리스트로 정리
    for field in ("keywords", "competitors"):
        value = brief.get(field)
        if isinstance(value, str):
            brief[field] = [v.strip() for v in value.split(",") if v.strip()]
        elif value is not None and not isinstance(value, list):
            brief[field] = [str(value)]
    return brief


def brief_to_text(brief: dict) -> str:
    lines = [
        f"- 업종: {brief['industry']}",
        f"- 타겟: {brief['target']}",
        f"- 키워드: {', '.join(map(str, brief['keywords']))}",
        f"- 톤앤매너: {brief.get('tone') or '브랜드에 어울리게 자유롭게'}",
    ]
    if brief.get("competitors"):
        lines.append(f"- 경쟁사: {', '.join(map(str, brief['competitors']))}")
    if brief.get("notes"):
        lines.append(f"- 추가 요청사항: {brief['notes']}")
    return "\n".join(lines)


SYSTEM_PROMPT = (
    "당신은 10년 경력의 브랜드 전략가이자 카피라이터입니다. "
    "모든 답변은 한국어로 작성하고, 반드시 요청한 형식의 JSON 객체로만 답하세요."
)


# ─────────────────────────────────────────────
# 1. 브랜드 네이밍 (3~5개 + 의미/유래, 한글·영문 동시 생성)
# ─────────────────────────────────────────────
def generate_names(brief: dict, key: str) -> list[dict]:
    prompt = f"""다음 브랜드 브리프에 맞는 브랜드명 후보를 4개 제안하세요.
{brief_to_text(brief)}

조건:
- 각 후보는 한글 브랜드명(korean)과 영문 브랜드명(english)을 함께 제시
- 각 후보의 의미/유래(meaning)를 한 문장으로 설명
- 경쟁사와 혼동되지 않는 이름
형식: {{"names": [{{"korean": "...", "english": "...", "meaning": "..."}}]}}"""
    raw = ask_llm_json(prompt, key).get("names", [])
    names = [
        {
            "korean": str(n.get("korean", "")).strip(),
            "english": str(n.get("english", "")).strip(),
            "meaning": str(n.get("meaning", "")).strip(),
        }
        for n in raw
        if isinstance(n, dict) and (n.get("korean") or n.get("english")) and n.get("meaning")
    ][:NAME_MAX]
    if len(names) < NAME_MIN:
        raise APICallError(f"네이밍 후보가 {len(names)}개만 생성되었습니다. (필요: {NAME_MIN}~{NAME_MAX}개)")
    return names


def display_name(n: dict) -> str:
    if n.get("korean") and n.get("english"):
        return f"{n['korean']} ({n['english']})"
    return n.get("korean") or n.get("english", "")


# ─────────────────────────────────────────────
# 2. 슬로건/태그라인 (정확히 3개, 톤앤매너 반영)
# ─────────────────────────────────────────────
def generate_slogans(brief: dict, brand_name: str, key: str) -> list[str]:
    tone = brief.get("tone") or "브랜드에 어울리는"
    prompt = f"""브랜드 '{brand_name}'의 슬로건/태그라인을 정확히 {SLOGAN_COUNT}개 만드세요.
{brief_to_text(brief)}

조건:
- 톤앤매너 '{tone}'을(를) 반드시 반영
- 각 20자 이내, 짧고 기억에 남는 문구, 서로 다른 관점
- 따옴표 없이 문구만
형식: {{"slogans": ["...", "...", "..."]}}"""
    raw = ask_llm_json(prompt, key).get("slogans", [])
    slogans = [str(s).strip().strip('"“”') for s in raw if str(s).strip()][:SLOGAN_COUNT]
    if len(slogans) < SLOGAN_COUNT:
        raise APICallError(f"슬로건이 {len(slogans)}개만 생성되었습니다. (필요: {SLOGAN_COUNT}개)")
    return slogans


# ─────────────────────────────────────────────
# 3. 브랜드 스토리 (300자 내외, 탄생 배경·철학·비전)
# ─────────────────────────────────────────────
def generate_story(brief: dict, brand_name: str, key: str) -> dict:
    base_prompt = f"""브랜드 '{brand_name}'의 브랜드 스토리를 작성하세요.
{brief_to_text(brief)}

조건:
- origin(탄생 배경), philosophy(철학), vision(비전)을 각각 한 문장으로 정리
- story: 위 세 가지를 모두 녹인 하나의 이야기, 공백 포함 {STORY_TARGET}자 내외({STORY_TARGET - 20}~{STORY_TARGET + 20}자)
형식: {{"origin": "...", "philosophy": "...", "vision": "...", "story": "..."}}"""

    result: dict = {}
    prompt = base_prompt
    for attempt in range(2):  # 길이가 크게 벗어나면 1회 재생성
        result = ask_llm_json(prompt, key)
        story = str(result.get("story", "")).strip()
        if not story:
            raise APICallError("브랜드 스토리가 생성되지 않았습니다.")
        if abs(len(story) - STORY_TARGET) <= STORY_TOLERANCE:
            break
        if attempt == 0:
            print(f"      ⚠ 스토리 길이 {len(story)}자 → {STORY_TARGET}자 내외로 다시 생성")
            prompt = base_prompt + f"\n\n직전 결과가 {len(story)}자였습니다. 반드시 {STORY_TARGET}자 내외로 맞추세요."

    story = str(result.get("story", "")).strip()
    return {
        "origin": str(result.get("origin", "")).strip(),
        "philosophy": str(result.get("philosophy", "")).strip(),
        "vision": str(result.get("vision", "")).strip(),
        "story": story,
        "length": len(story),
    }


# ─────────────────────────────────────────────
# 4. 컬러 팔레트 (메인 1 + 서브 2~3, HEX) + PNG 시각화
# ─────────────────────────────────────────────
def normalize_hex(value) -> str:
    h = str(value or "").strip()
    if not h.startswith("#"):
        h = "#" + h
    if re.fullmatch(r"#[0-9A-Fa-f]{3}", h):  # #ABC → #AABBCC
        h = "#" + "".join(c * 2 for c in h[1:])
    return h.upper()


def generate_colors(brief: dict, brand_name: str, key: str) -> dict:
    prompt = f"""브랜드 '{brand_name}'에 어울리는 컬러 팔레트를 추천하세요.
{brief_to_text(brief)}

조건:
- 메인 컬러(main) 1개, 서브 컬러(sub) 3개
- 모든 컬러는 HEX 코드(#RRGGBB)
- 각 컬러의 영문 이름(name)과 선택 이유(reason) 포함
형식: {{"main": {{"hex": "#RRGGBB", "name": "...", "reason": "..."}},
       "sub": [{{"hex": "#RRGGBB", "name": "...", "reason": "..."}}]}}"""
    data = ask_llm_json(prompt, key)

    def clean(c) -> dict | None:
        if not isinstance(c, dict):
            return None
        h = normalize_hex(c.get("hex"))
        if not HEX_RE.match(h):
            return None
        return {"hex": h, "name": str(c.get("name", "")).strip(), "reason": str(c.get("reason", "")).strip()}

    main = clean(data.get("main"))
    subs = [c for c in map(clean, data.get("sub") or []) if c][:SUB_MAX]
    if not main:
        raise APICallError(f"메인 컬러 HEX 코드가 올바르지 않습니다: {data.get('main')}")
    if len(subs) < SUB_MIN:
        raise APICallError(f"유효한 서브 컬러가 {len(subs)}개뿐입니다. (필요: {SUB_MIN}~{SUB_MAX}개)")
    return {"main": main, "sub": subs}


def setup_korean_font() -> None:
    """운영체제별 한글 폰트를 찾아 matplotlib에 적용한다."""
    candidates = ["Malgun Gothic", "AppleGothic", "Apple SD Gothic Neo", "NanumGothic",
                  "Noto Sans CJK KR", "Noto Sans KR", "Noto Sans CJK JP"]
    installed = {f.name for f in font_manager.fontManager.ttflist}
    for name in candidates:
        if name in installed:
            plt.rcParams["font.family"] = name
            break
    plt.rcParams["axes.unicode_minus"] = False


def text_color_for(hex_code: str) -> str:
    """배경 밝기에 따라 읽기 쉬운 글자색(검정/흰색)을 고른다."""
    r, g, b = (int(hex_code[i:i + 2], 16) for i in (1, 3, 5))
    return "#1A1A1A" if (0.299 * r + 0.587 * g + 0.114 * b) > 150 else "#FFFFFF"


def save_palette_image(palette: dict, brand_name: str, path: str) -> None:
    """matplotlib으로 컬러 팔레트를 그려 PNG로 저장한다."""
    setup_korean_font()
    swatches = [("MAIN", palette["main"])] + [(f"SUB {i}", c) for i, c in enumerate(palette["sub"], 1)]

    fig, ax = plt.subplots(figsize=(10, 4.5), dpi=150)
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 4.5)
    ax.axis("off")
    ax.text(0, 4.2, f"{brand_name}  Color Palette", fontsize=16, fontweight="bold", va="center")

    main_w = 4.0                                   # 메인 컬러는 넓게
    sub_w = (10 - main_w) / len(palette["sub"])    # 서브 컬러는 남은 폭을 균등 분할
    x = 0.0
    for label, c in swatches:
        w = main_w if label == "MAIN" else sub_w
        ax.add_patch(Rectangle((x, 0), w, 3.7, facecolor=c["hex"], edgecolor="white", linewidth=3))
        tc = text_color_for(c["hex"])
        ax.text(x + 0.2, 3.35, label, color=tc, fontsize=9, fontweight="bold", alpha=0.85)
        ax.text(x + 0.2, 0.75, c.get("name", ""), color=tc, fontsize=10)
        ax.text(x + 0.2, 0.3, c["hex"], color=tc, fontsize=13, fontweight="bold")
        x += w

    fig.savefig(path, format="png", bbox_inches="tight", facecolor="white")
    plt.close(fig)


# ─────────────────────────────────────────────
# 5. 로고 시안 (이미지 생성 API → PNG 2개)
# ─────────────────────────────────────────────
LOGO_STYLES = [
    "minimal flat vector emblem with a simple geometric symbol above the wordmark",
    "elegant line-art monogram built from the brand's initial letter, refined and modern",
    "friendly rounded badge with a soft organic icon",
]


def build_logo_prompt(brief: dict, name: dict, palette: dict | None, style: str) -> str:
    brand = name.get("english") or name.get("korean") or brief["industry"]
    colors = ""
    if palette:
        hexes = [palette["main"]["hex"]] + [c["hex"] for c in palette["sub"]]
        colors = f" Color palette: {', '.join(hexes)}."
    return (
        f'A professional brand logo for "{brand}". '
        f"Industry: {brief['industry']}. Target customers: {brief['target']}. "
        f"Brand keywords: {', '.join(map(str, brief['keywords']))}. "
        f"Mood: {brief.get('tone') or 'clean and trustworthy'}. "
        f"Style: {style}.{colors} "
        "Centered on a plain white background, flat 2D vector logo, no mockup, "
        "no extra text other than the brand name."
    )


# ─────────────────────────────────────────────
# (보너스) 경쟁사 분석
# ─────────────────────────────────────────────
def analyze_competitors(brief: dict, brand_name: str, key: str) -> dict:
    prompt = f"""브랜드 '{brand_name}'의 경쟁사를 분석하고 차별화 포인트를 제안하세요.
{brief_to_text(brief)}

형식: {{"competitors": [{{"name": "...", "positioning": "...", "strength": "...", "weakness": "..."}}],
       "differentiation": ["...", "...", "..."]}}"""
    data = ask_llm_json(prompt, key)
    if not data.get("differentiation"):
        raise APICallError("차별화 포인트가 생성되지 않았습니다.")
    return data


# ─────────────────────────────────────────────
# 전체 파이프라인
# ─────────────────────────────────────────────
def run(brief: dict, out_dir: str, api_key: str) -> dict:
    os.makedirs(out_dir, exist_ok=True)
    result: dict = {
        "brief": brief,
        "names": [],
        "selected_name": None,
        "slogans": [],
        "story": None,
        "color_palette": None,
        "files": {"result_json": None, "color_palette": None, "logos": []},
        "errors": [],
    }
    state = {"key_invalid": False}

    def stage(num: int | None, title: str, name: str, func) -> None:
        """한 단계를 실행한다. 실패해도 에러 메시지만 출력하고 다음 단계로 넘어간다."""
        label = f"[{num}/{TOTAL_STEPS}]" if num else "[보너스]"
        print(f"{label} {title} 생성 중...")
        if state["key_invalid"]:
            msg = "API 키가 유효하지 않아 이 단계를 건너뜁니다."
            print(f"  ❌ {msg}")
            result["errors"].append({"stage": name, "message": msg})
            return
        try:
            func()
        except APIKeyError as e:
            state["key_invalid"] = True
            print(f"  ❌ {e}")
            print("     → 다음 단계를 계속 진행합니다.")
            result["errors"].append({"stage": name, "message": str(e).splitlines()[0]})
        except Exception as e:  # API 실패·응답 형식 오류·파일 저장 오류 등
            print(f"  ❌ {title} 실패: {e}")
            print("     → 다음 단계를 계속 진행합니다.")
            result["errors"].append({"stage": name, "message": str(e)})

    # 이후 단계에서 쓸 대표 브랜드명 (네이밍 실패 시 업종명으로 대체)
    ctx = {"brand": brief["industry"], "name": {"korean": brief["industry"], "english": ""}}

    # [1/5] 네이밍
    def do_names():
        result["names"] = generate_names(brief, api_key)
        for n in result["names"]:
            print(f"  - {display_name(n)}: {n['meaning']}")
        ctx["name"] = result["names"][0]
        ctx["brand"] = ctx["name"]["korean"] or ctx["name"]["english"]
        result["selected_name"] = ctx["name"]

    stage(1, "브랜드 네이밍", "naming", do_names)

    # [2/5] 슬로건
    def do_slogans():
        result["slogans"] = generate_slogans(brief, ctx["brand"], api_key)
        for s in result["slogans"]:
            print(f'  - "{s}"')

    stage(2, "슬로건", "slogan", do_slogans)

    # [3/5] 브랜드 스토리
    def do_story():
        result["story"] = generate_story(brief, ctx["brand"], api_key)
        print(f"  - 스토리 생성 완료 ({result['story']['length']}자)")

    stage(3, "브랜드 스토리", "story", do_story)

    # [4/5] 컬러 팔레트 + 시각화
    def do_colors():
        palette = generate_colors(brief, ctx["brand"], api_key)
        result["color_palette"] = palette
        print(f"  - 메인: {palette['main']['hex']} ({palette['main']['name']})")
        print(f"  - 서브: {', '.join(c['hex'] for c in palette['sub'])}")
        path = os.path.join(out_dir, PALETTE_FILENAME)
        save_palette_image(palette, ctx["brand"], path)
        result["files"]["color_palette"] = path
        print(f"  - 저장: {path}")

    stage(4, "컬러 팔레트", "color_palette", do_colors)

    # [5/5] 로고 시안 (한 개가 실패해도 나머지는 계속 생성)
    def do_logos():
        failures = []
        for i in range(1, LOGO_COUNT + 1):
            if state["key_invalid"]:
                break
            prompt = build_logo_prompt(brief, ctx["name"], result["color_palette"],
                                       LOGO_STYLES[(i - 1) % len(LOGO_STYLES)])
            try:
                png = generate_image(prompt, api_key)
                path = os.path.join(out_dir, f"logo_{i:02d}.png")
                with open(path, "wb") as f:
                    f.write(png)
                result["files"]["logos"].append({"file": path, "prompt": prompt})
                print(f"  - 저장: {path}")
            except APIKeyError:
                raise
            except Exception as e:
                print(f"  ❌ 로고 {i} 생성 실패: {e}")
                failures.append({"stage": f"logo_{i:02d}", "message": str(e)})
        result["errors"].extend(failures)
        if failures and not result["files"]["logos"]:
            print("     → 다음 단계를 계속 진행합니다.")

    stage(5, "로고 시안", "logo", do_logos)

    # [보너스] 경쟁사 분석
    if brief.get("competitors"):
        def do_competitors():
            analysis = analyze_competitors(brief, ctx["brand"], api_key)
            result["competitor_analysis"] = analysis
            for d in analysis.get("differentiation", []):
                print(f"  - 차별화: {d}")

        stage(None, "경쟁사 분석", "competitor_analysis", do_competitors)

    # 결과 저장: 모든 텍스트 결과 → brand_result.json
    json_path = os.path.join(out_dir, RESULT_FILENAME)
    result["files"]["result_json"] = json_path
    try:
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
    except OSError as e:
        print(f"❌ {RESULT_FILENAME} 저장 실패: {e}")
    return result


# ─────────────────────────────────────────────
# 대화형 입력 (print / input)
# ─────────────────────────────────────────────
def main() -> None:
    print("\n🎨 AI 브랜드 아이덴티티 생성기\n")

    # API 키 확인 (없거나 형식이 틀리면 안내 후 종료)
    try:
        api_key = load_api_key()
    except APIKeyError as e:
        print(f"❌ {e}")
        sys.exit(1)

    try:
        # 필수 입력: 브리프 파일 경로 (올바른 파일을 입력할 때까지 다시 묻는다)
        while True:
            brief_path = input("브리프 파일 경로를 입력하세요: ").strip().strip('"').strip("'")
            if not brief_path:
                print("  ⚠ 브리프 파일 경로는 필수 입력입니다.\n")
                continue
            try:
                brief = load_brief(brief_path)
                break
            except ValueError as e:
                print(f"  ❌ {e}\n")

        # 선택 입력: 출력 폴더 경로 (기본값 ./output)
        while True:
            out_dir = input(f"출력 폴더 경로를 입력하세요 (엔터 시 {DEFAULT_OUTPUT_DIR}): ").strip().strip('"').strip("'")
            out_dir = out_dir or DEFAULT_OUTPUT_DIR
            try:
                os.makedirs(out_dir, exist_ok=True)
                break
            except OSError as e:
                print(f"  ❌ 출력 폴더를 만들 수 없습니다: {e}\n")
    except (EOFError, KeyboardInterrupt):
        print("\n입력이 취소되었습니다.")
        sys.exit(1)

    print()
    try:
        result = run(brief, out_dir, api_key)
    except KeyboardInterrupt:
        print("\n중단되었습니다.")
        sys.exit(130)

    folder = out_dir if out_dir.endswith(("/", "\\")) else out_dir + "/"
    print()
    if result["errors"]:
        print(f"⚠️  {len(result['errors'])}개 항목이 실패했습니다. (상세 내용: {result['files']['result_json']}의 errors)")
    print(f"✅ 완료! {folder} 폴더를 확인하세요.")


if __name__ == "__main__":
    main()
